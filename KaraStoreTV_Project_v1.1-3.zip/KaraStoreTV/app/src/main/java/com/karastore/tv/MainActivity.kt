package com.karastore.tv

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as PlayerMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class MediaItem(val title: String, val subtitle: String, val type: String)

private val Gold = Color(0xFFE7B83F)
private val Dark = Color(0xFF080606)
private val Card = Color(0xFF171111)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KaraStoreApp() }
    }
}

@Composable
fun KaraStoreApp() {
    var activated by remember { mutableStateOf(false) }
    if (!activated) {
        ActivationScreen { activated = true }
    } else {
        MainScreen()
    }
}

@Composable
fun ActivationScreen(onActivated: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }

    Box(
        Modifier.fillMaxSize().background(Dark),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.width(520.dp).focusable(),
            colors = CardDefaults.cardColors(containerColor = Card),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                Modifier.padding(34.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("كارة ستور", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Text("تفعيل التطبيق", color = Color.White, fontSize = 24.sp)
                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it; error = false },
                    label = { Text("اسم المستخدم") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(focus)
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it; error = false },
                    label = { Text("كود التفعيل") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = {
                        // Demo activation only. Replace this with your own authorized backend/API.
                        if (username.isNotBlank() && code == "KARA-2026") onActivated()
                        else error = true
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp).focusable(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold)
                ) {
                    Text("تفعيل", color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                if (error) {
                    Spacer(Modifier.height(10.dp))
                    Text("بيانات التفعيل غير صحيحة", color = Color(0xFFFF8A80))
                }
                Spacer(Modifier.height(14.dp))
                Text("للتجربة: كود التفعيل KARA-2026", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun MainScreen() {
    var selected by remember { mutableStateOf("الرئيسية") }
    var query by remember { mutableStateOf("") }
    var showPlayer by remember { mutableStateOf(false) }
    val nav = listOf("الرئيسية", "مباشر", "أفلام", "مسلسلات", "المفضلة", "الإعدادات")

    if (showPlayer) {
        PlayerScreen(onBack = { showPlayer = false })
        return
    }

    Box(Modifier.fillMaxSize().background(Dark)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("كارة ستور", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(26.dp))
                nav.forEach { item ->
                    Text(
                        item,
                        color = if (selected == item) Gold else Color.White,
                        fontSize = 18.sp,
                        fontWeight = if (selected == item) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                            .focusable().clickable { selected = item }
                    )
                }
                Spacer(Modifier.weight(1f))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("بحث") },
                    modifier = Modifier.width(190.dp)
                )
            }

            Spacer(Modifier.height(28.dp))
            when (selected) {
                "الرئيسية" -> HomeScreen(onPlay = { showPlayer = true })
                "مباشر" -> MediaScreen("القنوات المباشرة", demo("مباشر"), onPlay = { showPlayer = true })
                "أفلام" -> MediaScreen("أحدث الأفلام", demo("فيلم"), onPlay = { showPlayer = true })
                "مسلسلات" -> MediaScreen("المسلسلات", demo("مسلسل"), onPlay = { showPlayer = true })
                "المفضلة" -> MediaScreen("المفضلة", demo("مفضلة"), onPlay = { showPlayer = true })
                "الإعدادات" -> SettingsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onPlay: () -> Unit) {
    Column {
        Text("أهلاً بك في كارة ستور", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("واجهة تجريبية جاهزة للتطوير وربط المحتوى الخاص بك", color = Color.LightGray, fontSize = 16.sp)
        Spacer(Modifier.height(24.dp))
        Section("الأقسام الرئيسية", demo("قسم"), onPlay)
        Spacer(Modifier.height(20.dp))
        Section("اختيارات كارة ستور", demo("محتوى"), onPlay)
    }
}

@Composable
fun Section(title: String, items: List<MediaItem>, onPlay: () -> Unit) {
    Column {
        Text(title, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items) { item -> MediaCard(item, onPlay) }
        }
    }
}

@Composable
fun MediaScreen(title: String, items: List<MediaItem>, onPlay: () -> Unit) {
    Column {
        Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items) { item -> MediaCard(item, onPlay) }
        }
    }
}

@Composable
fun MediaCard(item: MediaItem, onPlay: () -> Unit) {
    Card(
        modifier = Modifier.width(190.dp).height(145.dp).focusable().clickable { onPlay() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(90.dp).background(Color(0xFF241313)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (item.type == "مباشر") "▶" else "KARA", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Text(item.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
            Text(item.subtitle, color = Color.Gray, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 12.dp))
        }
    }
}

@Composable
fun PlayerScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(PlayerMediaItem.fromUri(Uri.parse(
                "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            )))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
            modifier = Modifier.fillMaxSize()
        )
        Text(
            "رجوع",
            color = Color.White,
            modifier = Modifier.padding(24.dp).focusable().clickable { onBack() },
            fontSize = 18.sp
        )
    }
}

@Composable
fun SettingsScreen() {
    Column {
        Text("الإعدادات", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text("هذه نسخة تجريبية. اربط لاحقاً API تملكه أو تملك حق استخدامه.", color = Color.LightGray, fontSize = 17.sp)
        Spacer(Modifier.height(18.dp))
        listOf("جودة التشغيل", "اللغة", "التحكم بالريموت", "حول التطبيق").forEach {
            Text(it, color = Color.White, fontSize = 18.sp,
                modifier = Modifier.padding(vertical = 10.dp).focusable())
        }
    }
}

fun demo(type: String): List<MediaItem> =
    (1..8).map { MediaItem("$type $it", "محتوى تجريبي", type) }
